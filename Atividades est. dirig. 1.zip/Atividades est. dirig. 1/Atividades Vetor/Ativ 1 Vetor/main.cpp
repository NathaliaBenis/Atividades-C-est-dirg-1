#include <iostream>

using namespace std;

int main () {

    int vetor[5];
    int impar = 0;

    for(int i = 0;  i < 5; i++) {
        cout << "Digite um valor qualquer: ";
        cin >> vetor[i];

        if (vetor[i] %2 != 0) {
            impar +=vetor[i];
        }
    }

    cout << "soma dos elementos impares: " <<impar;
    return 0;
}
